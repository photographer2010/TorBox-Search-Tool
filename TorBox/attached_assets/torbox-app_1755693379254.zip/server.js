import express from "express";
import fetch from "node-fetch";
import cors from "cors";
import FormData from "form-data";

const app = express();
app.use(cors());
app.use(express.json());

// Torrent search via Knaben
app.get("/api/search", async (req, res) => {
  const q = req.query.q;
  if (!q) return res.status(400).json({ error: "Missing q" });

  try {
    const resp = await fetch(`https://api.knaben.org/v1/search?q=${encodeURIComponent(q)}`);
    const data = await resp.json();
    res.json(data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Knaben search failed" });
  }
});

// Send torrent to TorBox
app.post("/api/send", async (req, res) => {
  const { apiKey, magnet } = req.body;
  if (!apiKey || !magnet) return res.status(400).json({ error: "Missing apiKey or magnet" });

  try {
    const form = new FormData();
    form.append("magnet", magnet);
    form.append("seed", "1");
    form.append("allow_zip", "true");

    const tbResp = await fetch("https://api.torbox.app/v1/api/torrents/createtorrent", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}` },
      body: form,
    });

    const data = await tbResp.json();
    res.status(tbResp.status).json(data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "TorBox request failed" });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`✅ Backend running on http://localhost:${PORT}`));
