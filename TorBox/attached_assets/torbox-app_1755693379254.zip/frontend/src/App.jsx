import { useState } from "react";

export default function App() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [torboxKey, setTorboxKey] = useState("");

  const handleSearch = async () => {
    const res = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
    const data = await res.json();
    setResults(data.torrents || data); // Knaben returns {torrents: [...]}
  };

  const sendToTorbox = async (magnet) => {
    if (!torboxKey) {
      alert("Please enter your TorBox API key first!");
      return;
    }
    await fetch("/api/send", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ apiKey: torboxKey, magnet }),
    });
    alert("Sent to TorBox!");
  };

  return (
    <div style={{ padding: "20px", fontFamily: "sans-serif" }}>
      <h1>TorBox Search</h1>
      <input
        placeholder="Your TorBox API Key"
        value={torboxKey}
        onChange={(e) => setTorboxKey(e.target.value)}
        style={{ width: "400px" }}
      />
      <br /><br />
      <input
        placeholder="Search torrents..."
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        style={{ width: "400px" }}
      />
      <button onClick={handleSearch}>Search</button>
      <ul>
        {results.map((r, i) => (
          <li key={i}>
            <b>{r.title}</b> ({r.size})
            <button onClick={() => sendToTorbox(r.magnet)} style={{ marginLeft: "10px" }}>
              Send to TorBox
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
